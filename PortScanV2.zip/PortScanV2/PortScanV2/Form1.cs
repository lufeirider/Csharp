﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PortScanV2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //==============================================================================
        //全局变量定义区
        DateTime startTime;
        Int32 i;
        Int32 socketNum;
        Int32 maxSocketNum;
        Socket socket;
        SocketAsyncEventArgs socketAsync;
        String ip;
        System.Threading.Timer timer;
        Int32 openPortNum;
        String nmapUsage;
        String nmapVpnUsage;
        List<String> openPortList;
        //==============================================================================

        //==============================================================================
        //更新ResultTextBox
        delegate void AppendTextHandler(String str);
        private void AppendText(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new AppendTextHandler(AppendText), str);
                return;
            }
            ResultTextBox.AppendText(str);
        }
        //==============================================================================


        //==============================================================================
        public void Scan()
        {
            openPortList = new List<String>();
            openPortNum = 0;
            for (i = 1; i < 65535; i++)
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socketAsync = new SocketAsyncEventArgs();
                socketAsync.RemoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), i);
                socketAsync.UserToken = socket;
                socketAsync.Completed += new EventHandler<SocketAsyncEventArgs>(SocketAsyncCompleted);
                socket.ConnectAsync(socketAsync);

                Interlocked.Increment(ref socketNum);
                while (socketNum > maxSocketNum)
                {
                    Thread.Sleep(50);
                }
            }
            timer.Dispose();
            RateToolStripStatusLabel.Text = "进度：100%";
            AppendText("==========================================================\n");
            nmapUsage = "nmap -v -sV -Pn " + ip + " -p";
            nmapVpnUsage = "nmap -v -sV -Pn --unprivileged " + ip + " -p";
            foreach (var port in openPortList)
            {
                nmapUsage += port + ",";
                nmapVpnUsage += port + ",";
            }
            AppendText("当使用vpn nmap：" + "\n");
            AppendText(nmapUsage + "\n");
            AppendText("==========================================================\n");
            AppendText("nmap：" + "\n");
            AppendText(nmapUsage + "\n");
        }

        private void SocketAsyncCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.ConnectSocket != null)
            {
                ResultToolStripStatusLabel.Text = "扫描结果：" + (++openPortNum) + "个";
                AppendText(((IPEndPoint)e.RemoteEndPoint).Port.ToString() + "\n");
                openPortList.Add(((IPEndPoint)e.RemoteEndPoint).Port.ToString());
            }
            ((Socket)e.UserToken).Dispose();
            Interlocked.Decrement(ref socketNum);

        }

        public void RefreshStatus(object o)
        {
            RateToolStripStatusLabel.Text = "进度：" + (Math.Round(Convert.ToDouble(i / Convert.ToDouble(65535)), 2) * 100).ToString() + "%";
            ToalTimeToolStripStatusLabel.Text = (DateTime.Now - startTime).ToString().Substring(0, 8);

        }

        public void Init()
        {
            if (IpTextBox.Text == null)
            {
                MessageBox.Show("ip 地址不能为空");
            }
            else
            {
                ip = IpTextBox.Text;
            }

            maxSocketNum = Convert.ToInt32(MaxSocketNumTextBox.Text);

            timer = new System.Threading.Timer(new TimerCallback(RefreshStatus), null, 0, 1000);
            startTime = DateTime.Now;
            ResultTextBox.Text = "";
        }


        private void ScanButton_Click(object sender, EventArgs e)
        {
            Init();
            Task t = new Task(Scan);
            t.Start();
        }
    }
}
