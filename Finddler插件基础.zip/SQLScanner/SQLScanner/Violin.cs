﻿using System;
using System.Windows.Forms;
using Fiddler;


public class Violin : IAutoTamper    // Ensure class is public, or Fiddler won't see it!
{

    UserInterface _userPage;
    public Violin()
    {
        /* NOTE: It's possible that Fiddler UI isn't fully loaded yet, so don't add any UI in the constructor.

           But it's also possible that AutoTamper* methods are called before OnLoad (below), so be
           sure any needed data structures are initialized to safe values here in this constructor */


    }

    public void OnLoad()
    {
        /* Load your UI here */
        _userPage = new UserInterface();
    }

    public void OnBeforeUnload() { }

    public void AutoTamperRequestBefore(Session oSession)
    {
        
    }
    public void AutoTamperRequestAfter(Session oSession) { }
    public void AutoTamperResponseBefore(Session oSession) { }
    public void AutoTamperResponseAfter(Session oSession) { }
    public void OnBeforeReturningError(Session oSession) { }
}