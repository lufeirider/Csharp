﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Fiddler;

public partial class UserInterface : UserControl
{
    private TextBox textBox_Info;
    private TabPage tabPage; //添加一个标签页 用来放置控件

    public UserInterface()
    {
        InitializeComponent();
        FiddlerApplication.UI.tabsViews.TabPages.Add(this.tabPage); //新建一个tabPage
    }

    private void InitializeComponent()
    {
        this.tabPage = new TabPage("SQLScanner");
        this.tabPage.AutoScroll = true;

        this.textBox_Info = new System.Windows.Forms.TextBox();
        this.SuspendLayout();
        // 
        // textBox_Info
        // 
        this.textBox_Info.Location = new System.Drawing.Point(3, 3);
        this.textBox_Info.Multiline = true;
        this.textBox_Info.Name = "textBox_Info";
        this.textBox_Info.Size = new System.Drawing.Size(1140, 599);
        this.textBox_Info.TabIndex = 0;
        // 
        // UserInterface
        // 
        this.tabPage.Controls.Add(this.textBox_Info);
        this.tabPage.Name = "UserInterface";
        this.tabPage.Size = new System.Drawing.Size(1146, 642);
        this.tabPage.ResumeLayout(false);
        this.tabPage.PerformLayout();

    }
}

