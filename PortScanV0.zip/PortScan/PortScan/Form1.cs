﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace PortScan
{
    //=========================================================================
    //定义多端口扫描的结构体
    struct infos
    {
        public String ip;
        public String startPort;
        public String endPort;
    }
    //=========================================================================

    
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        //=========================================================================
        //全局变量声明
        Int32 portNum = 0;
        DateTime startTime;
        Int32 finishCount = 0;

        infos info = new infos();
        object locker = new object();
        

        ParameterizedThreadStart s;
        Thread thread;
        static List<string> portList = new List<string>();

        //=========================================================================



        //=========================================================================
        //设置timer的状态的函数
        public void setTimerStatus(object o)
        {

                //endTime = System.Environment.TickCount;
                //runTime = endTime - startTime + 1;

                //SetText("endTime is :" + endTime.ToString() + "\n");

                //toolStripStatusLabel2.Text = "扫描用时：" + (runTime / 1000.0).ToString() + " s";


        }
        //=========================================================================


        //=========================================================================
        //因为不是主线程不能直接对控件操作，使用委托更新端口扫描信息
        delegate void AppendTextHandler(string str);
        
        private void SetText(string obj)
        {
            if (this.textBox1.InvokeRequired)
            {
                this.textBox1.Invoke(new AppendTextHandler(this.AppendText), obj);
            }
            else
            {
                this.textBox1.AppendText(obj);
            }

        }

        private void AppendText(string str)
        {
            this.textBox1.AppendText(str);
        }

        //=========================================================================



        //=========================================================================
        //多端口多线程扫描
        //多线程的回调函数的参数一定是boject类型
        public void MultiPortTcpScanThread(object info)
        {
            Int32 i;
            infos rowInfo = (infos)info;


            //SetText(rowInfo.ip);
            //SetText(rowInfo.startPort);
            //SetText(rowInfo.endPort);


            ThreadPool.SetMaxThreads(50, 50);
            for (i = Convert.ToInt32(rowInfo.startPort); i <= Convert.ToInt32(rowInfo.endPort); i++)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(TcpScanTest), (Int32)i);
            }


            lock (locker)
            {
                while (finishCount != Convert.ToInt32(rowInfo.endPort) - Convert.ToInt32(rowInfo.startPort) + 1)
                {
                    Monitor.Wait(locker);
                    

                    //endTime = System.Environment.TickCount;
                    //runTime = endTime - startTime + 1;
                    //SetText("endTime is :" + endTime.ToString() + "\n");
                    SetText(DateTime.Now.ToString()+"\n");
                    toolStripStatusLabel2.Text = "扫描用时：" + (DateTime.Now - startTime).ToString().Substring(0, 8);


                    Thread.Sleep(1000);
                }
            }

            SetText("==========================================================\n");
            String summary = "";
            String nmap = "nmap -v -sV -Pn " + rowInfo.ip + " -p";
            String vpnNmap = "nmap -v -sV -Pn --unprivileged " + rowInfo.ip + " -p";
            foreach (var port in portList)
            {
                summary += rowInfo.ip + ":" + port + "\r\n";
                nmap += port + ",";
                vpnNmap += port + ",";
                
            }
            SetText("开放的端口：" + "\n");
            SetText(summary);
            SetText("==========================================================\n");
            SetText("当使用vpn nmap："+"\n");
            SetText(vpnNmap + "\n");
            SetText("==========================================================\n");
            SetText("nmap：" + "\n");
            SetText(nmap + "\n");
            SetText("==========================================================\n");
            


        }
        //=========================================================================


        //=========================================================================
        //单线程多端口扫描
        public void MultiPortTcpScan(String ip, String startPort, String endPort)
        {
           
            Int32 port;
            for (port = Convert.ToInt32(startPort); port <= Convert.ToInt32(endPort); port++)
            {
                TcpScan(ip,port.ToString());
            }
            
        }
        //=========================================================================


        //=========================================================================
        //多线程使用的单端口扫描
        public void TcpScanTest(object port)
        {

            String ip = textBox2.Text;
            String msg = "";
            TcpClient tcp = new TcpClient();

            try
            {
                tcp.Connect(IPAddress.Parse(ip), Convert.ToInt32(port));
                toolStripStatusLabel1.Text = "扫描结果：" + ++portNum + " 个";
                msg = "ip: " + ip + "   ***端口开放：" + port.ToString() + "***\n";
                portList.Add(port.ToString());
                //SetText(portList[0]);
                SetText(msg);
                tcp.Close();
                lock (locker)
                {
                    finishCount++;
                    Monitor.Pulse(locker);
                }


            }
            catch
            {
                msg = "ip: " + ip + " 端口关闭：" + port.ToString() + "\n";
                SetText(msg);
                lock (locker)
                {
                    finishCount++;
                    Monitor.Pulse(locker);
                }

            }
        }
        //=========================================================================

        //=========================================================================
        //单线程，单端口扫描
        public void TcpScan(String ip, String port)
        {
            String msg = "";
            TcpClient tcp = new TcpClient();

            try{
                tcp.Connect(IPAddress.Parse(ip), Convert.ToInt32(port));
                msg = "ip: " + ip + " ***端口开放：" + port.ToString() + "***\n";
                SetText(msg);
                tcp.Close();
                lock (locker)
                { 
                    
                }

            }
            catch {
                msg = "ip: " + ip + " 端口关闭：" + port.ToString() + "\n";
                SetText(msg);
            }
        }
        //=========================================================================


        private void Form1_Load(object sender, EventArgs e)
        {

            toolStripStatusLabel2.Text = "扫描用时：" + (startTime - startTime).ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //=========================================================================
            //参数初始化

            //获取startTime
            //startTime = System.Environment.TickCount;
            startTime = DateTime.Now;  


            portNum = 0;
            toolStripStatusLabel1.Text = "扫描结果：" + portNum + " 个";

            
            
            toolStripStatusLabel2.Text = "扫描用时：" + (startTime-startTime).ToString();

            finishCount = 0;

            portList.Clear();

            info.ip = textBox2.Text;
            info.startPort = textBox3.Text;
            info.endPort = textBox4.Text;
            //=========================================================================




            //=========================================================================
            //开启线程
            s = new ParameterizedThreadStart(MultiPortTcpScanThread);
            thread = new Thread(s);
            thread.Start(info);

            //=========================================================================
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //=========================================================================
            //清理扫描结果
            textBox1.Text = "";
            //=========================================================================
        }

    }
}
