﻿using System;
using System.Windows.Forms;
using Fiddler;
using System.Threading;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

public class Violin : IAutoTamper    // Ensure class is public, or Fiddler won't see it!
{

    public UserInterface sqlPage = new UserInterface();
    public static List<UrlInfo> checkedUrlList = new List<UrlInfo>();




    public Violin()
    {
        /* NOTE: It's possible that Fiddler UI isn't fully loaded yet, so don't add any UI in the constructor.
        But it's also possible that AutoTamper* methods are called before OnLoad (below), so be
        sure any needed data structures are initialized to safe values here in this constructor */
        

    }

    public void OnLoad()
    {
        /* Load your UI here */
    }

    public void OnBeforeUnload() { }


    public void AutoTamperRequestBefore(Session oSession)
    {


    }

    public void AutoTamperRequestAfter(Session oSession) { }
    public void AutoTamperResponseBefore(Session oSession) { }
    public void AutoTamperResponseAfter(Session oSession)
    {
        #region 变量定义区
        UrlInfo curUrlInfo = new UrlInfo();
        
        String paramsStr;
        String[] paramsArr;

        StringDictionary dictionary = new StringDictionary();
        dictionary["Repeate"] = "ok";
        dictionary["Length"] = oSession.oResponse.headers["Content-Length"];
        dictionary["OldId"] = oSession.id.ToString();

        HTTPRequestHeaders sqlReqHeader = new HTTPRequestHeaders();
        sqlReqHeader = (HTTPRequestHeaders)oSession.RequestHeaders.Clone();

        String pattern = @"\/\w+\.(asp|aspx|php|jsp|\?)";
        Regex regex = new Regex(pattern);

        Int32 isExist = 0;
        #endregion


        #region 检测重复
        curUrlInfo.domain = oSession.oRequest.host;
        curUrlInfo.file = regex.Match(oSession.PathAndQuery).Value;

        for (Int32 i = 0; i < checkedUrlList.Count; i++)
        {
            if ((checkedUrlList[i].domain == curUrlInfo.domain) && (checkedUrlList[i].file == curUrlInfo.file))
            {
                isExist = 1;
                break;
            }
        }

        
        #endregion
        

        //判断是不是重发包
        if ((oSession.oFlags["Repeate"] != "ok") && (isExist == 0))
        {
            //判断是否包含.asp .aspx .php
            if (regex.IsMatch(oSession.PathAndQuery))
            {
                checkedUrlList.Add(curUrlInfo);
                //GET SQL检测
                if (oSession.oRequest.headers.HTTPMethod == "GET" && oSession.PathAndQuery.Contains("?"))
                {
                    paramsStr = oSession.PathAndQuery.Split('?')[1];
                    paramsArr = paramsStr.Split('&');
                    foreach (String tempStr in paramsArr)
                    {
                        //字符型 ‘检测SQL注入检测
                        sqlReqHeader.RequestPath = sqlReqHeader.RequestPath.Replace(tempStr, tempStr + "%27");
                    }

                    FiddlerApplication.oProxy.InjectCustomRequest(sqlReqHeader, oSession.requestBodyBytes, dictionary);
                }//POST SQL检测 只检测application/x-www-form-urlencoded 类型的
                else if (oSession.oRequest.headers.HTTPMethod == "POST" && oSession.oRequest.headers["Content-Type"] == "application/x-www-form-urlencoded")
                {
                    paramsStr = oSession.GetRequestBodyEncoding().GetString(oSession.requestBodyBytes);
                    paramsArr = paramsStr.Split('&');
                    foreach(String tempStr in paramsArr)
                    {
                        //字符型 ‘检测SQL注入检测
                        paramsStr = paramsStr.Replace(tempStr, tempStr + "%27");
                    }

                    FiddlerApplication.oProxy.InjectCustomRequest(oSession.oRequest.headers, oSession.GetRequestBodyEncoding().GetBytes(paramsStr), dictionary);

                }
            }
        }//处理
        else if(oSession.oFlags["Repeate"] == "ok")
        {
            //第一种，添加#，判断返回结果是200 长度不一样 就判断是SQL注入
            if (oSession.responseCode == 200 && oSession.oResponse.headers["Content-Length"] != oSession.oFlags["Length"])
            {
                sqlPage.AddResult("长度判断型");
                sqlPage.AddResult("原始包:" + oSession.oFlags["OldId"]);
                sqlPage.AddResult("SQL包:" + oSession.id.ToString());
                sqlPage.AddResult(oSession.RequestHeaders.ToString());
                sqlPage.AddResult(oSession.GetRequestBodyEncoding().GetString(oSession.requestBodyBytes).Replace("%27",""));

                sqlPage.AppendLogToFile("d:/log.txt","长度判断型");
                sqlPage.AppendLogToFile("d:/log.txt", "原始包:" + oSession.oFlags["OldId"]);
                sqlPage.AppendLogToFile("d:/log.txt", "SQL包:" + oSession.id.ToString());
                sqlPage.AppendLogToFile("d:/log.txt", oSession.RequestHeaders.ToString());
                sqlPage.AppendLogToFile("d:/log.txt", oSession.GetRequestBodyEncoding().GetString(oSession.requestBodyBytes).Replace("%27", ""));
            }//第二种，判断返回状态是不是500，判断返回的结果是包含80040e14。
            else if (oSession.responseCode == 500)
            {
                String patternAccess = @"80040e14";
                Regex regexAccess = new Regex(patternAccess);
                if (regexAccess.IsMatch(oSession.GetResponseBodyEncoding().GetString(oSession.responseBodyBytes)))
                {
                    sqlPage.AddResult("报错型");
                    sqlPage.AddResult("原始包:" + oSession.oFlags["OldId"]);
                    sqlPage.AddResult("SQL包:" + oSession.id.ToString());
                    sqlPage.AddResult(oSession.RequestHeaders.ToString());
                    sqlPage.AddResult(oSession.GetRequestBodyEncoding().GetString(oSession.requestBodyBytes).Replace("%27", ""));

                    sqlPage.AppendLogToFile("d:/log.txt", "长度判断型");
                    sqlPage.AppendLogToFile("d:/log.txt", "原始包:" + oSession.oFlags["OldId"]);
                    sqlPage.AppendLogToFile("d:/log.txt", "SQL包:" + oSession.id.ToString());
                    sqlPage.AppendLogToFile("d:/log.txt", oSession.RequestHeaders.ToString());
                    sqlPage.AppendLogToFile("d:/log.txt", oSession.GetRequestBodyEncoding().GetString(oSession.requestBodyBytes).Replace("%27", ""));
                }
            }
        }

    }
    public void OnBeforeReturningError(Session oSession) { }

}