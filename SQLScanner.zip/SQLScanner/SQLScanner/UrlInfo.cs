﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class UrlInfo
{
    public String domain;
    public String file;
    public UrlInfo()
    {
        domain = "";
        file = "";
    }
}

