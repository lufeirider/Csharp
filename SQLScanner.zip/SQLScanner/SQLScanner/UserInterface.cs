﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Fiddler;
using System.IO;

public partial class UserInterface : UserControl
{
    private TextBox textBox_Info;
    private Button button_Clear;
    private TabPage tabPage; //添加一个标签页 用来放置控件

    public UserInterface()
    {
        InitializeComponent();
        DiyIInitializeComponent();
        FiddlerApplication.UI.tabsViews.TabPages.Add(this.tabPage); //新建一个tabPage
    }

    public delegate void AppendTextHandler(String str);
    public void AppendText(String str)
    {
        if (InvokeRequired)
        {
            Invoke(new AppendTextHandler(AppendText), str);
            return;
        }
        else
        {
            textBox_Info.AppendText(str);
        }  
    }


    public delegate void Delegate_AddResult(string strUrl);//定义输出结果的委托
    public void AddResult(string strUrl)
    {
        if (!this.textBox_Info.InvokeRequired)
            this.textBox_Info.AppendText(strUrl + "\r\n");
        else
        {
            Delegate_AddResult delegate_addresult = new Delegate_AddResult(this.AddResult);
            this.textBox_Info.Invoke(delegate_addresult, strUrl);
        }
    }


    public void AppendLogToFile(String path, String log)
    {
        FileStream fs = null;
        StreamWriter sw = null;
        try
        {
            fs = new FileStream(path, FileMode.Append, FileAccess.Write);
            sw = new StreamWriter(fs);
            sw.WriteLine(log);
            sw.Close();
            fs.Close();
        }
        catch{}
    }

    private void InitializeComponent()
    {
            this.textBox_Info = new System.Windows.Forms.TextBox();
            this.button_Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_Info
            // 
            this.textBox_Info.Location = new System.Drawing.Point(3, 3);
            this.textBox_Info.Multiline = true;
            this.textBox_Info.Name = "textBox_Info";
            this.textBox_Info.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_Info.Size = new System.Drawing.Size(1140, 605);
            this.textBox_Info.TabIndex = 0;
            // 
            // button_Clear
            // 
            this.button_Clear.Location = new System.Drawing.Point(475, 641);
            this.button_Clear.Name = "button_Clear";
            this.button_Clear.Size = new System.Drawing.Size(75, 23);
            this.button_Clear.TabIndex = 1;
            this.button_Clear.Text = "Clear";
            this.button_Clear.UseVisualStyleBackColor = true;
            this.button_Clear.Click += new System.EventHandler(this.button_Clear_Click);
            // 
            // UserInterface
            // 
            //this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            //this.Controls.Add(this.button_Clear);
            //this.Controls.Add(this.textBox_Info);
            //this.Name = "UserInterface";
            //this.Size = new System.Drawing.Size(1170, 695);
            //this.ResumeLayout(false);
            //this.PerformLayout();

    }

    private void DiyIInitializeComponent()
    {
        this.tabPage = new TabPage("SQLScanner");

        this.tabPage.Controls.Add(this.textBox_Info);
        this.tabPage.Controls.Add(this.button_Clear);
        this.tabPage.Name = "UserInterface";
        this.tabPage.Size = new System.Drawing.Size(1146, 642);
        this.tabPage.ResumeLayout(false);
        this.tabPage.PerformLayout();
    }

    private void button_Clear_Click(object sender, EventArgs e)
    {
        textBox_Info.Text = "";
        Violin.checkedUrlList.Clear();
    }
}

