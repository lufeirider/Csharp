﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PortScan
{
    class FormOperation
    {
        
        
        //===================================================================================================
        //委托对textbox添加内容
        delegate void AppendTextHandler(AppendTextBoxInfo info);

        public void AppendTextFun(AppendTextBoxInfo info)
        {
            info.textBox.AppendText(info.appendStr);
        }

        public void AppendText(AppendTextBoxInfo obj)
        {
            if (obj.textBox.InvokeRequired)
            {
                obj.textBox.Invoke(new AppendTextHandler(AppendTextFun), obj);
            }
            else
            {
                obj.textBox.AppendText(obj.appendStr);
            }
        }
        //===================================================================================================

        public void SetPortStatus(SetStatusInfo setStatusInfo)
        {

            setStatusInfo.PortNumToolStripStatusLabel.Text = setStatusInfo.Setstr;

        }

        public void SetRateStatus(object mulitiScanPara)
        {
            MulitiScanPara inMulitiScanPara = (MulitiScanPara)mulitiScanPara;
            inMulitiScanPara.setStatusInfo.RateToolStripStatusLabel.Text = "进度：100%";
        }

        public void SetTimeStatus(object mulitiScanPara)
        {
            MulitiScanPara inMulitiScanPara = (MulitiScanPara)mulitiScanPara;
            inMulitiScanPara.setStatusInfo.Setstr = "扫描用时：" + (DateTime.Now - inMulitiScanPara.setStatusInfo.startTime).ToString().Substring(0, 8);
            inMulitiScanPara.setStatusInfo.ToalTimeToolStripStatusLabel.Text = inMulitiScanPara.setStatusInfo.Setstr;


            int MaxWorkerThreads, miot, AvailableWorkerThreads, aiot;
            //获得最大的线程数量  
            ThreadPool.GetMaxThreads(out MaxWorkerThreads, out miot);
            AvailableWorkerThreads = aiot = 0;
            //获得可用的线程数量  
            ThreadPool.GetAvailableThreads(out AvailableWorkerThreads, out aiot);
            //返回线程池中活动的线程数  
            inMulitiScanPara.setStatusInfo.ThreadCountToolStripStatusLabel.Text = "线程数量：" + (MaxWorkerThreads - AvailableWorkerThreads).ToString();

            //int id = Thread.CurrentThread.ManagedThreadId;
            //MessageBox.Show(id.ToString());
            inMulitiScanPara.setStatusInfo.RateToolStripStatusLabel.Text = "进度：" + (Math.Round(Convert.ToDouble(TcpScan.finishCount / Convert.ToDouble(inMulitiScanPara.setStatusInfo.count)),2)*100).ToString() + "%";

        }

        public void AppendTextBox(TextBox textbox)
        {
            textbox.AppendText("lufie\n");
        }
    }
}
