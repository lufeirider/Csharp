﻿namespace PortScan
{
    partial class PortScanForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.IpTextBox = new System.Windows.Forms.TextBox();
            this.IpLabel = new System.Windows.Forms.Label();
            this.StartPortTextBox = new System.Windows.Forms.TextBox();
            this.EndPortTextBox = new System.Windows.Forms.TextBox();
            this.StartPortLabel = new System.Windows.Forms.Label();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.CancelButton = new System.Windows.Forms.Button();
            this.ScanButton = new System.Windows.Forms.Button();
            this.RowLabel = new System.Windows.Forms.Label();
            this.ResultTextBox = new System.Windows.Forms.TextBox();
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.PortNumToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ThreadCountToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.RateToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ToalTimeToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.MainPanel.SuspendLayout();
            this.StatusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // IpTextBox
            // 
            this.IpTextBox.Location = new System.Drawing.Point(57, 23);
            this.IpTextBox.Name = "IpTextBox";
            this.IpTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.IpTextBox.Size = new System.Drawing.Size(100, 21);
            this.IpTextBox.TabIndex = 0;
            this.IpTextBox.Text = "172.16.51.116";
            // 
            // IpLabel
            // 
            this.IpLabel.AutoSize = true;
            this.IpLabel.Location = new System.Drawing.Point(-2, 26);
            this.IpLabel.Name = "IpLabel";
            this.IpLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.IpLabel.Size = new System.Drawing.Size(53, 12);
            this.IpLabel.TabIndex = 1;
            this.IpLabel.Text = "Ip地址：";
            // 
            // StartPortTextBox
            // 
            this.StartPortTextBox.Location = new System.Drawing.Point(257, 23);
            this.StartPortTextBox.Name = "StartPortTextBox";
            this.StartPortTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPortTextBox.Size = new System.Drawing.Size(100, 21);
            this.StartPortTextBox.TabIndex = 3;
            this.StartPortTextBox.Text = "21";
            // 
            // EndPortTextBox
            // 
            this.EndPortTextBox.Location = new System.Drawing.Point(386, 23);
            this.EndPortTextBox.Name = "EndPortTextBox";
            this.EndPortTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EndPortTextBox.Size = new System.Drawing.Size(100, 21);
            this.EndPortTextBox.TabIndex = 5;
            this.EndPortTextBox.Text = "41";
            // 
            // StartPortLabel
            // 
            this.StartPortLabel.AutoSize = true;
            this.StartPortLabel.Location = new System.Drawing.Point(186, 26);
            this.StartPortLabel.Name = "StartPortLabel";
            this.StartPortLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPortLabel.Size = new System.Drawing.Size(65, 12);
            this.StartPortLabel.TabIndex = 4;
            this.StartPortLabel.Text = "起始端口：";
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.CancelButton);
            this.MainPanel.Controls.Add(this.ScanButton);
            this.MainPanel.Controls.Add(this.RowLabel);
            this.MainPanel.Controls.Add(this.EndPortTextBox);
            this.MainPanel.Controls.Add(this.IpLabel);
            this.MainPanel.Controls.Add(this.StartPortLabel);
            this.MainPanel.Controls.Add(this.IpTextBox);
            this.MainPanel.Controls.Add(this.StartPortTextBox);
            this.MainPanel.Location = new System.Drawing.Point(13, 3);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(710, 66);
            this.MainPanel.TabIndex = 3;
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(632, 21);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 6;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // ScanButton
            // 
            this.ScanButton.Location = new System.Drawing.Point(513, 21);
            this.ScanButton.Name = "ScanButton";
            this.ScanButton.Size = new System.Drawing.Size(75, 23);
            this.ScanButton.TabIndex = 7;
            this.ScanButton.Text = "Scan";
            this.ScanButton.UseVisualStyleBackColor = true;
            this.ScanButton.Click += new System.EventHandler(this.ScanButton_Click);
            // 
            // RowLabel
            // 
            this.RowLabel.AutoSize = true;
            this.RowLabel.Location = new System.Drawing.Point(363, 26);
            this.RowLabel.Name = "RowLabel";
            this.RowLabel.Size = new System.Drawing.Size(17, 12);
            this.RowLabel.TabIndex = 6;
            this.RowLabel.Text = "->";
            // 
            // ResultTextBox
            // 
            this.ResultTextBox.Location = new System.Drawing.Point(13, 75);
            this.ResultTextBox.Multiline = true;
            this.ResultTextBox.Name = "ResultTextBox";
            this.ResultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ResultTextBox.Size = new System.Drawing.Size(710, 303);
            this.ResultTextBox.TabIndex = 4;
            // 
            // StatusStrip
            // 
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PortNumToolStripStatusLabel,
            this.ThreadCountToolStripStatusLabel,
            this.RateToolStripStatusLabel,
            this.ToalTimeToolStripStatusLabel});
            this.StatusStrip.Location = new System.Drawing.Point(0, 364);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.Size = new System.Drawing.Size(735, 26);
            this.StatusStrip.SizingGrip = false;
            this.StatusStrip.TabIndex = 5;
            this.StatusStrip.Text = "StatusStrip";
            // 
            // PortNumToolStripStatusLabel
            // 
            this.PortNumToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.PortNumToolStripStatusLabel.Name = "PortNumToolStripStatusLabel";
            this.PortNumToolStripStatusLabel.Size = new System.Drawing.Size(95, 21);
            this.PortNumToolStripStatusLabel.Text = "扫描结果：0 个";
            // 
            // ThreadCountToolStripStatusLabel
            // 
            this.ThreadCountToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ThreadCountToolStripStatusLabel.Name = "ThreadCountToolStripStatusLabel";
            this.ThreadCountToolStripStatusLabel.Size = new System.Drawing.Size(87, 21);
            this.ThreadCountToolStripStatusLabel.Text = "线程数量： 0 ";
            // 
            // RateToolStripStatusLabel
            // 
            this.RateToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.RateToolStripStatusLabel.Name = "RateToolStripStatusLabel";
            this.RateToolStripStatusLabel.Size = new System.Drawing.Size(70, 21);
            this.RateToolStripStatusLabel.Text = "进度：0 %";
            // 
            // ToalTimeToolStripStatusLabel
            // 
            this.ToalTimeToolStripStatusLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ToalTimeToolStripStatusLabel.Name = "ToalTimeToolStripStatusLabel";
            this.ToalTimeToolStripStatusLabel.Size = new System.Drawing.Size(120, 21);
            this.ToalTimeToolStripStatusLabel.Text = "扫描用时：00:00:00";
            // 
            // PortScanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 390);
            this.Controls.Add(this.StatusStrip);
            this.Controls.Add(this.ResultTextBox);
            this.Controls.Add(this.MainPanel);
            this.Name = "PortScanForm";
            this.Text = "PortScan";
            this.Load += new System.EventHandler(this.PortScanForm_Load);
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IpTextBox;
        private System.Windows.Forms.Label IpLabel;
        private System.Windows.Forms.TextBox EndPortTextBox;
        private System.Windows.Forms.Label StartPortLabel;
        private System.Windows.Forms.TextBox StartPortTextBox;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Label RowLabel;
        private System.Windows.Forms.Button ScanButton;
        private System.Windows.Forms.TextBox ResultTextBox;
        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.ToolStripStatusLabel PortNumToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel ToalTimeToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel ThreadCountToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel RateToolStripStatusLabel;
        private System.Windows.Forms.Button CancelButton;
    }
}

