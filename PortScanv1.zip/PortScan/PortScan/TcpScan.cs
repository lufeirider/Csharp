﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace PortScan
{
    class TcpScan
    {
        public Int32 i;
        FormOperation formOper = new FormOperation();
        object locker = new object();
        static List<String> portList = new List<String>();
        public static Int32 finishCount = 0;
        public static CancellationTokenSource tokenSource;
        public CancellationToken token;
        Int32 openPortNum = 0;

        public String MulitiThreadPortScan(MulitiScanPara mulitiScanPara)
        {
            //===================================================================================================
            //初始化
            Control.CheckForIllegalCrossThreadCalls = false;
            finishCount = 0;
            portList.Clear();
            openPortNum = 0;

            mulitiScanPara.setStatusInfo.Setstr = "扫描结果：0 个";
            formOper.SetPortStatus(mulitiScanPara.setStatusInfo);

            tokenSource = mulitiScanPara.threadPara.cancelTokenSource;
            token = mulitiScanPara.threadPara.token;
            


            //===================================================================================================
            //timer
            System.Threading.Timer timer;
            mulitiScanPara.setStatusInfo.startTime = DateTime.Now;
            mulitiScanPara.setStatusInfo.count = Convert.ToInt32(mulitiScanPara.scanPara.endPort) - Convert.ToInt32(mulitiScanPara.scanPara.startPort) + 1;
            timer = new System.Threading.Timer(new System.Threading.TimerCallback(formOper.SetTimeStatus), mulitiScanPara, 0, 1000);
            //===================================================================================================

            while (!token.IsCancellationRequested)
            {
                if (!token.IsCancellationRequested)
                {
                    ThreadPool.SetMaxThreads(1000, 1000);
                    for (i = Convert.ToInt32(mulitiScanPara.scanPara.startPort); i <= Convert.ToInt32(mulitiScanPara.scanPara.endPort); i++)
                    {
                        mulitiScanPara.scanPara.port = i.ToString();
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadPortScan), mulitiScanPara);
                    }

                    lock (locker)
                    {
                        while (finishCount != Convert.ToInt32(mulitiScanPara.scanPara.endPort) - Convert.ToInt32(mulitiScanPara.scanPara.startPort) + 1)
                        {
                            Monitor.Wait(locker);
                        }
                    }


                    formOper.SetRateStatus(mulitiScanPara);
                    mulitiScanPara.appendInfo.appendStr = "==========================================================\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    String summary = "";
                    String nmap = "nmap -v -sV -Pn " + mulitiScanPara.scanPara.ip + " -p";
                    String vpnNmap = "nmap -v -sV -Pn --unprivileged " + mulitiScanPara.scanPara.ip + " -p";
                    foreach (var port in portList)
                    {
                        summary += mulitiScanPara.scanPara.ip + ":" + port + "\r\n";
                        nmap += port + ",";
                        vpnNmap += port + ",";

                    }

                    mulitiScanPara.appendInfo.appendStr = "开放的端口：" + "\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = summary;
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = "==========================================================\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = "当使用vpn nmap：" + "\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = vpnNmap + "\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = "==========================================================\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = "nmap：" + "\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = nmap + "\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    mulitiScanPara.appendInfo.appendStr = "==========================================================\n";
                    formOper.AppendText(mulitiScanPara.appendInfo);

                    timer.Dispose();
                    tokenSource.Cancel();
                }
                else
                {
                    formOper.SetRateStatus(mulitiScanPara);
                    timer.Dispose();
                    tokenSource.Cancel();
                }

            }
            return "";
        }

        //===================================================================================================
        //多线程单端口扫描
        public void ThreadPortScan(object mulitiScanPara)
        {
            if (token.IsCancellationRequested)
                return; 

            MulitiScanPara inMulitiScanPara = (MulitiScanPara)mulitiScanPara;
            String msg = "";
            TcpClient tcp = new TcpClient();

            try
            {
                tcp.Connect(IPAddress.Parse(inMulitiScanPara.scanPara.ip), Convert.ToInt32(inMulitiScanPara.scanPara.port));
                msg = "ip: " + inMulitiScanPara.scanPara.ip + " ***端口开放：" + inMulitiScanPara.scanPara.port + "***\n";
                tcp.Close();
                inMulitiScanPara.appendInfo.appendStr = msg;
                formOper.AppendText(inMulitiScanPara.appendInfo);

                inMulitiScanPara.setStatusInfo.Setstr = "扫描结果：" + (++openPortNum).ToString() + "个";
                formOper.SetPortStatus(inMulitiScanPara.setStatusInfo);

                //放在追加textbox后面，放在前面可能因为速度太快，导致无法添加到列表当中去
                portList.Add(inMulitiScanPara.scanPara.port);
                

                lock (locker)
                {
                    finishCount++;
                    Monitor.Pulse(locker);
                }
            }
            catch
            {
                msg = "ip: " + inMulitiScanPara.scanPara.ip + " 端口关闭：" + inMulitiScanPara.scanPara.port + "\n";
                inMulitiScanPara.appendInfo.appendStr = msg;
                formOper.AppendText(inMulitiScanPara.appendInfo);
                lock (locker)
                {
                    finishCount++;
                    Monitor.Pulse(locker);
                }
            }
        }
        //===================================================================================================
        //===================================================================================================
        //===================================================================================================
        //===================================================================================================
        //===================================================================================================


        //===================================================================================================
        //单线程单端口扫描
        public String ThreadPortScan(ScanPara scanPara)
        {
            String msg = "";
            TcpClient tcp = new TcpClient();

            try
            {
                tcp.Connect(IPAddress.Parse(scanPara.ip), Convert.ToInt32(scanPara.port));
                msg = "ip: " + scanPara.ip + " ***端口开放：" + scanPara.port + "***\n";
                return msg;
            }
            catch
            {
                msg = "ip: " + scanPara.ip + " 端口关闭：" + scanPara.port + "\n";
                return msg;
            }
        }
        //===================================================================================================



        //===================================================================================================
        //主线程单端口扫描
        public String SinglePortScan(String ip, String port)
        {
            String msg = "";
            TcpClient tcp = new TcpClient();

            try
            {
                tcp.Connect(IPAddress.Parse(ip), Convert.ToInt32(port));
                msg = "ip: " + ip + " ***端口开放：" + port.ToString() + "***\n";
                return msg;
            }
            catch
            {
                msg = "ip: " + ip + " 端口关闭：" + port.ToString() + "\n";
                return msg;
            }
        }
        //===================================================================================================
    }
}