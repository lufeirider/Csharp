﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PortScan
{
    public struct ScanPara
    {
        public String ip;
        public String port;
        public String startPort;
        public String endPort;
    }

    //追到内容到textbox下面
    public struct AppendTextBoxInfo
    {
        public TextBox textBox;
        public String appendStr;
    }

    public struct SetStatusInfo
    {
        public ToolStripLabel PortNumToolStripStatusLabel;
        public ToolStripLabel ToalTimeToolStripStatusLabel;
        public ToolStripLabel ThreadCountToolStripStatusLabel;
        public ToolStripLabel RateToolStripStatusLabel;
        public Int32 count;
        public String Setstr;
        public DateTime startTime;
    }

    public struct ThreadPara
    {
        public CancellationTokenSource cancelTokenSource;
        public CancellationToken token;
    }

    public struct MulitiScanPara
    {
        public ScanPara scanPara;
        public AppendTextBoxInfo appendInfo;
        public SetStatusInfo setStatusInfo;
        public ThreadPara threadPara;
    }



    class PublicClass
    {

    }
}
