﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PortScan
{
    public partial class PortScanForm : Form
    {
        public PortScanForm()
        {
            InitializeComponent();
        }
        //===================================================================================================

        //===================================================================================================
        //全局变量定义
        TcpScan tcpScan;
        MulitiScanPara mulitiScanPara;
        
        FormOperation formOperation;

        Task<String> t;
        //===================================================================================================

        private void PortScanForm_Load(object sender, EventArgs e)
        {
            //===================================================================================================
            //初始化
            tcpScan = new TcpScan();
            formOperation = new FormOperation();
            //===================================================================================================
        }

        private void ScanButton_Click(object sender, EventArgs e)
        {
            //===================================================================================================
            //初始化
            ResultTextBox.Text = "";



            mulitiScanPara.appendInfo.textBox = ResultTextBox;
            mulitiScanPara.scanPara.ip = IpTextBox.Text;
            mulitiScanPara.scanPara.startPort = StartPortTextBox.Text;
            mulitiScanPara.scanPara.endPort = EndPortTextBox.Text;
            mulitiScanPara.setStatusInfo.PortNumToolStripStatusLabel = PortNumToolStripStatusLabel;
            mulitiScanPara.setStatusInfo.ToalTimeToolStripStatusLabel = ToalTimeToolStripStatusLabel;
            mulitiScanPara.setStatusInfo.ThreadCountToolStripStatusLabel = ThreadCountToolStripStatusLabel;
            mulitiScanPara.setStatusInfo.RateToolStripStatusLabel = RateToolStripStatusLabel;

            mulitiScanPara.threadPara.cancelTokenSource = new CancellationTokenSource();
            mulitiScanPara.threadPara.token = mulitiScanPara.threadPara.cancelTokenSource.Token;

            t = new Task<String>(() => tcpScan.MulitiThreadPortScan(mulitiScanPara));
            t.Start();
            //Task contunueT = t.ContinueWith(task => { MessageBox.Show("11111") ; });



            
            //===================================================================================================
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            TcpScan.tokenSource.Cancel();
        }
}
}
