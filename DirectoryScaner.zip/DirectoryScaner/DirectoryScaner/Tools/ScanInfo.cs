﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectoryScaner.Tools
{
    class ScanInfo
    {
        public string id;
        public string path;
        public string statusCode;
        public string length;
        public ScanInfo()
        {
            statusCode = "404";
            length = "0";
        }
    }
}
