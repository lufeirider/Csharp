﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DirectoryScaner.Tools
{
    class FileTools
    {
        public static List<String> ReadFileToList(String path)
        {

            List<String> list = new List<String>();
            FileStream fs = null;
            StreamReader sr = null;
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.Read);

                sr = new StreamReader(fs);

                String lineStr;

                while ((lineStr = sr.ReadLine()) != null)
                {
                    if (!lineStr.Equals(""))
                    {
                        list.Add(lineStr);
                    }
                }
            }
            catch (Exception)
            {
                if (sr != null)
                {
                    sr.Close();
                }
                if (fs != null)
                {
                    fs.Close();
                }

            }
            return list;
        }
    }
}
