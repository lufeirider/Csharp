﻿namespace DirectoryScaner
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_Scan = new System.Windows.Forms.Button();
            this.label_domain = new System.Windows.Forms.Label();
            this.groupBox_Top = new System.Windows.Forms.GroupBox();
            this.button_Stop = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_MaxDelay = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_Mindelay = new System.Windows.Forms.TextBox();
            this.radioButton_waf = new System.Windows.Forms.RadioButton();
            this.textBox_Domain = new System.Windows.Forms.TextBox();
            this.listView_Filter = new System.Windows.Forms.ListView();
            this.column_FilterStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_FilterLength = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button_Filter = new System.Windows.Forms.Button();
            this.groupBox_Result = new System.Windows.Forms.GroupBox();
            this.listView_Result = new System.Windows.Forms.ListView();
            this.column_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_url = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_length = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip_right = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem_copy = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_OpenAll = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox_Info = new System.Windows.Forms.GroupBox();
            this.label_Time = new System.Windows.Forms.Label();
            this.label_ThreadNum = new System.Windows.Forms.Label();
            this.label_Percentage = new System.Windows.Forms.Label();
            this.label_Url = new System.Windows.Forms.Label();
            this.timer_info = new System.Windows.Forms.Timer(this.components);
            this.button_Restore = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listView_Checked = new System.Windows.Forms.ListView();
            this.column_Dir = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_Count = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox_Top.SuspendLayout();
            this.groupBox_Result.SuspendLayout();
            this.contextMenuStrip_right.SuspendLayout();
            this.groupBox_Info.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Scan
            // 
            this.button_Scan.Location = new System.Drawing.Point(546, 20);
            this.button_Scan.Name = "button_Scan";
            this.button_Scan.Size = new System.Drawing.Size(75, 23);
            this.button_Scan.TabIndex = 0;
            this.button_Scan.Text = "Scan";
            this.button_Scan.UseVisualStyleBackColor = true;
            this.button_Scan.Click += new System.EventHandler(this.button_scan_Click);
            // 
            // label_domain
            // 
            this.label_domain.AutoSize = true;
            this.label_domain.Location = new System.Drawing.Point(6, 23);
            this.label_domain.Name = "label_domain";
            this.label_domain.Size = new System.Drawing.Size(41, 12);
            this.label_domain.TabIndex = 1;
            this.label_domain.Text = "域名：";
            // 
            // groupBox_Top
            // 
            this.groupBox_Top.Controls.Add(this.button_Stop);
            this.groupBox_Top.Controls.Add(this.label3);
            this.groupBox_Top.Controls.Add(this.label2);
            this.groupBox_Top.Controls.Add(this.textBox_MaxDelay);
            this.groupBox_Top.Controls.Add(this.label1);
            this.groupBox_Top.Controls.Add(this.textBox_Mindelay);
            this.groupBox_Top.Controls.Add(this.radioButton_waf);
            this.groupBox_Top.Controls.Add(this.textBox_Domain);
            this.groupBox_Top.Controls.Add(this.label_domain);
            this.groupBox_Top.Controls.Add(this.button_Scan);
            this.groupBox_Top.Location = new System.Drawing.Point(12, 4);
            this.groupBox_Top.Name = "groupBox_Top";
            this.groupBox_Top.Size = new System.Drawing.Size(637, 86);
            this.groupBox_Top.TabIndex = 2;
            this.groupBox_Top.TabStop = false;
            // 
            // button_Stop
            // 
            this.button_Stop.Location = new System.Drawing.Point(546, 51);
            this.button_Stop.Name = "button_Stop";
            this.button_Stop.Size = new System.Drawing.Size(75, 23);
            this.button_Stop.TabIndex = 18;
            this.button_Stop.Text = "Stop";
            this.button_Stop.UseVisualStyleBackColor = true;
            this.button_Stop.Click += new System.EventHandler(this.button_Stop_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 17;
            this.label3.Text = "选项：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(401, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 16;
            this.label2.Text = "~";
            // 
            // textBox_MaxDelay
            // 
            this.textBox_MaxDelay.Location = new System.Drawing.Point(440, 53);
            this.textBox_MaxDelay.Name = "textBox_MaxDelay";
            this.textBox_MaxDelay.Size = new System.Drawing.Size(100, 21);
            this.textBox_MaxDelay.TabIndex = 15;
            this.textBox_MaxDelay.Text = "2000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(222, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "延迟：";
            // 
            // textBox_Mindelay
            // 
            this.textBox_Mindelay.Location = new System.Drawing.Point(280, 53);
            this.textBox_Mindelay.Name = "textBox_Mindelay";
            this.textBox_Mindelay.Size = new System.Drawing.Size(100, 21);
            this.textBox_Mindelay.TabIndex = 13;
            this.textBox_Mindelay.Text = "1000";
            // 
            // radioButton_waf
            // 
            this.radioButton_waf.AutoSize = true;
            this.radioButton_waf.Location = new System.Drawing.Point(53, 55);
            this.radioButton_waf.Name = "radioButton_waf";
            this.radioButton_waf.Size = new System.Drawing.Size(65, 16);
            this.radioButton_waf.TabIndex = 12;
            this.radioButton_waf.TabStop = true;
            this.radioButton_waf.Text = "waf模式";
            this.radioButton_waf.UseVisualStyleBackColor = true;
            // 
            // textBox_Domain
            // 
            this.textBox_Domain.Location = new System.Drawing.Point(53, 20);
            this.textBox_Domain.Name = "textBox_Domain";
            this.textBox_Domain.Size = new System.Drawing.Size(487, 21);
            this.textBox_Domain.TabIndex = 2;
            this.textBox_Domain.Text = "http://123.206.115.55/";
            // 
            // listView_Filter
            // 
            this.listView_Filter.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_FilterStatus,
            this.column_FilterLength});
            this.listView_Filter.GridLines = true;
            this.listView_Filter.LabelEdit = true;
            this.listView_Filter.Location = new System.Drawing.Point(6, 20);
            this.listView_Filter.Name = "listView_Filter";
            this.listView_Filter.Size = new System.Drawing.Size(150, 116);
            this.listView_Filter.TabIndex = 10;
            this.listView_Filter.UseCompatibleStateImageBehavior = false;
            this.listView_Filter.View = System.Windows.Forms.View.Details;
            // 
            // column_FilterStatus
            // 
            this.column_FilterStatus.Text = "响应码";
            this.column_FilterStatus.Width = 75;
            // 
            // column_FilterLength
            // 
            this.column_FilterLength.Text = "长度";
            this.column_FilterLength.Width = 75;
            // 
            // button_Filter
            // 
            this.button_Filter.Location = new System.Drawing.Point(4, 142);
            this.button_Filter.Name = "button_Filter";
            this.button_Filter.Size = new System.Drawing.Size(75, 23);
            this.button_Filter.TabIndex = 9;
            this.button_Filter.Text = "过滤";
            this.button_Filter.UseVisualStyleBackColor = true;
            this.button_Filter.Click += new System.EventHandler(this.button_Filter_Click);
            // 
            // groupBox_Result
            // 
            this.groupBox_Result.Controls.Add(this.listView_Result);
            this.groupBox_Result.Location = new System.Drawing.Point(12, 175);
            this.groupBox_Result.Name = "groupBox_Result";
            this.groupBox_Result.Size = new System.Drawing.Size(637, 342);
            this.groupBox_Result.TabIndex = 3;
            this.groupBox_Result.TabStop = false;
            // 
            // listView_Result
            // 
            this.listView_Result.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_id,
            this.column_url,
            this.column_status,
            this.column_length});
            this.listView_Result.ContextMenuStrip = this.contextMenuStrip_right;
            this.listView_Result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_Result.ForeColor = System.Drawing.Color.LimeGreen;
            this.listView_Result.FullRowSelect = true;
            this.listView_Result.GridLines = true;
            this.listView_Result.Location = new System.Drawing.Point(3, 17);
            this.listView_Result.Name = "listView_Result";
            this.listView_Result.Size = new System.Drawing.Size(631, 322);
            this.listView_Result.TabIndex = 0;
            this.listView_Result.UseCompatibleStateImageBehavior = false;
            this.listView_Result.View = System.Windows.Forms.View.Details;
            this.listView_Result.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView_Result_ColumnClick);
            this.listView_Result.DoubleClick += new System.EventHandler(this.listView_re_DoubleClick);
            // 
            // column_id
            // 
            this.column_id.Text = "序号";
            this.column_id.Width = 61;
            // 
            // column_url
            // 
            this.column_url.Text = "web路径";
            this.column_url.Width = 364;
            // 
            // column_status
            // 
            this.column_status.Text = "响应码";
            this.column_status.Width = 100;
            // 
            // column_length
            // 
            this.column_length.Text = "长度";
            this.column_length.Width = 100;
            // 
            // contextMenuStrip_right
            // 
            this.contextMenuStrip_right.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_copy,
            this.ToolStripMenuItem_OpenAll});
            this.contextMenuStrip_right.Name = "contextMenuStrip_right";
            this.contextMenuStrip_right.Size = new System.Drawing.Size(125, 48);
            // 
            // ToolStripMenuItem_copy
            // 
            this.ToolStripMenuItem_copy.Name = "ToolStripMenuItem_copy";
            this.ToolStripMenuItem_copy.Size = new System.Drawing.Size(124, 22);
            this.ToolStripMenuItem_copy.Text = "复     制";
            this.ToolStripMenuItem_copy.Click += new System.EventHandler(this.ToolStripMenuItem_copy_Click);
            // 
            // ToolStripMenuItem_OpenAll
            // 
            this.ToolStripMenuItem_OpenAll.Name = "ToolStripMenuItem_OpenAll";
            this.ToolStripMenuItem_OpenAll.Size = new System.Drawing.Size(124, 22);
            this.ToolStripMenuItem_OpenAll.Text = "全部打开";
            this.ToolStripMenuItem_OpenAll.Click += new System.EventHandler(this.ToolStripMenuItem_OpenAll_Click);
            // 
            // groupBox_Info
            // 
            this.groupBox_Info.Controls.Add(this.label_Time);
            this.groupBox_Info.Controls.Add(this.label_ThreadNum);
            this.groupBox_Info.Controls.Add(this.label_Percentage);
            this.groupBox_Info.Controls.Add(this.label_Url);
            this.groupBox_Info.Location = new System.Drawing.Point(13, 97);
            this.groupBox_Info.Name = "groupBox_Info";
            this.groupBox_Info.Size = new System.Drawing.Size(636, 72);
            this.groupBox_Info.TabIndex = 4;
            this.groupBox_Info.TabStop = false;
            // 
            // label_Time
            // 
            this.label_Time.AutoSize = true;
            this.label_Time.Location = new System.Drawing.Point(526, 17);
            this.label_Time.Name = "label_Time";
            this.label_Time.Size = new System.Drawing.Size(53, 12);
            this.label_Time.TabIndex = 3;
            this.label_Time.Text = "用时： 0";
            // 
            // label_ThreadNum
            // 
            this.label_ThreadNum.AutoSize = true;
            this.label_ThreadNum.Location = new System.Drawing.Point(265, 17);
            this.label_ThreadNum.Name = "label_ThreadNum";
            this.label_ThreadNum.Size = new System.Drawing.Size(71, 12);
            this.label_ThreadNum.TabIndex = 2;
            this.label_ThreadNum.Text = "当前线程：0";
            // 
            // label_Percentage
            // 
            this.label_Percentage.AutoSize = true;
            this.label_Percentage.Location = new System.Drawing.Point(5, 17);
            this.label_Percentage.Name = "label_Percentage";
            this.label_Percentage.Size = new System.Drawing.Size(95, 12);
            this.label_Percentage.TabIndex = 1;
            this.label_Percentage.Text = "完成情况：0 / 0";
            // 
            // label_Url
            // 
            this.label_Url.AutoSize = true;
            this.label_Url.Location = new System.Drawing.Point(5, 49);
            this.label_Url.Name = "label_Url";
            this.label_Url.Size = new System.Drawing.Size(107, 12);
            this.label_Url.TabIndex = 0;
            this.label_Url.Text = "当前url：等待扫描";
            // 
            // timer_info
            // 
            this.timer_info.Interval = 1000;
            this.timer_info.Tick += new System.EventHandler(this.timer_info_Tick);
            // 
            // button_Restore
            // 
            this.button_Restore.Location = new System.Drawing.Point(85, 142);
            this.button_Restore.Name = "button_Restore";
            this.button_Restore.Size = new System.Drawing.Size(75, 23);
            this.button_Restore.TabIndex = 11;
            this.button_Restore.Text = "还 原";
            this.button_Restore.UseVisualStyleBackColor = true;
            this.button_Restore.Click += new System.EventHandler(this.button_Restore_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listView_Checked);
            this.groupBox1.Controls.Add(this.listView_Filter);
            this.groupBox1.Controls.Add(this.button_Restore);
            this.groupBox1.Controls.Add(this.button_Filter);
            this.groupBox1.Location = new System.Drawing.Point(656, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(161, 513);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // listView_Checked
            // 
            this.listView_Checked.CheckBoxes = true;
            this.listView_Checked.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_Dir,
            this.column_Count});
            this.listView_Checked.FullRowSelect = true;
            this.listView_Checked.GridLines = true;
            this.listView_Checked.Location = new System.Drawing.Point(7, 188);
            this.listView_Checked.Name = "listView_Checked";
            this.listView_Checked.Size = new System.Drawing.Size(149, 319);
            this.listView_Checked.TabIndex = 12;
            this.listView_Checked.UseCompatibleStateImageBehavior = false;
            this.listView_Checked.View = System.Windows.Forms.View.Details;
            this.listView_Checked.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.listView_Checked_ItemCheck);
            // 
            // column_Dir
            // 
            this.column_Dir.Text = "字典";
            this.column_Dir.Width = 105;
            // 
            // column_Count
            // 
            this.column_Count.Text = "数量";
            this.column_Count.Width = 44;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 532);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_Info);
            this.Controls.Add(this.groupBox_Result);
            this.Controls.Add(this.groupBox_Top);
            this.Name = "Main";
            this.Text = "Directory Scanner";
            this.Load += new System.EventHandler(this.Main_Load);
            this.groupBox_Top.ResumeLayout(false);
            this.groupBox_Top.PerformLayout();
            this.groupBox_Result.ResumeLayout(false);
            this.contextMenuStrip_right.ResumeLayout(false);
            this.groupBox_Info.ResumeLayout(false);
            this.groupBox_Info.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Scan;
        private System.Windows.Forms.Label label_domain;
        private System.Windows.Forms.GroupBox groupBox_Top;
        private System.Windows.Forms.TextBox textBox_Domain;
        private System.Windows.Forms.GroupBox groupBox_Result;
        private System.Windows.Forms.ListView listView_Result;
        private System.Windows.Forms.ColumnHeader column_id;
        private System.Windows.Forms.ColumnHeader column_url;
        private System.Windows.Forms.ColumnHeader column_status;
        private System.Windows.Forms.ColumnHeader column_length;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_right;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_copy;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_OpenAll;
        private System.Windows.Forms.GroupBox groupBox_Info;
        private System.Windows.Forms.Label label_Url;
        private System.Windows.Forms.Timer timer_info;
        private System.Windows.Forms.Label label_Percentage;
        private System.Windows.Forms.Label label_ThreadNum;
        private System.Windows.Forms.Label label_Time;
        private System.Windows.Forms.Button button_Filter;
        private System.Windows.Forms.ListView listView_Filter;
        private System.Windows.Forms.ColumnHeader column_FilterStatus;
        private System.Windows.Forms.ColumnHeader column_FilterLength;
        private System.Windows.Forms.Button button_Restore;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton_waf;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_Mindelay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_MaxDelay;
        private System.Windows.Forms.Button button_Stop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView listView_Checked;
        private System.Windows.Forms.ColumnHeader column_Dir;
        private System.Windows.Forms.ColumnHeader column_Count;
    }
}

