﻿namespace DirectoryScaner
{
    partial class FilterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Status = new System.Windows.Forms.TextBox();
            this.textBox_Length = new System.Windows.Forms.TextBox();
            this.button_Add = new System.Windows.Forms.Button();
            this.label_StatusCode = new System.Windows.Forms.Label();
            this.label_Length = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_Status
            // 
            this.textBox_Status.Location = new System.Drawing.Point(70, 12);
            this.textBox_Status.Name = "textBox_Status";
            this.textBox_Status.Size = new System.Drawing.Size(119, 21);
            this.textBox_Status.TabIndex = 0;
            // 
            // textBox_Length
            // 
            this.textBox_Length.Location = new System.Drawing.Point(70, 52);
            this.textBox_Length.Name = "textBox_Length";
            this.textBox_Length.Size = new System.Drawing.Size(119, 21);
            this.textBox_Length.TabIndex = 1;
            // 
            // button_Add
            // 
            this.button_Add.Location = new System.Drawing.Point(70, 94);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(75, 23);
            this.button_Add.TabIndex = 2;
            this.button_Add.Text = "添    加";
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_StatusCode
            // 
            this.label_StatusCode.AutoSize = true;
            this.label_StatusCode.Location = new System.Drawing.Point(12, 15);
            this.label_StatusCode.Name = "label_StatusCode";
            this.label_StatusCode.Size = new System.Drawing.Size(53, 12);
            this.label_StatusCode.TabIndex = 3;
            this.label_StatusCode.Text = "响应码：";
            // 
            // label_Length
            // 
            this.label_Length.AutoSize = true;
            this.label_Length.Location = new System.Drawing.Point(12, 55);
            this.label_Length.Name = "label_Length";
            this.label_Length.Size = new System.Drawing.Size(47, 12);
            this.label_Length.TabIndex = 4;
            this.label_Length.Text = "长 度：";
            // 
            // FilterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(201, 139);
            this.Controls.Add(this.label_Length);
            this.Controls.Add(this.label_StatusCode);
            this.Controls.Add(this.button_Add);
            this.Controls.Add(this.textBox_Length);
            this.Controls.Add(this.textBox_Status);
            this.Name = "FilterForm";
            this.Text = "FilterForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Status;
        private System.Windows.Forms.TextBox textBox_Length;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Label label_StatusCode;
        private System.Windows.Forms.Label label_Length;
    }
}