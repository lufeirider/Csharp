﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DirectoryScaner
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        #region 变量定义区
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        String domain;
        public static int tNum = 0;
        public static int tCount = 0;
        public static int curConnNum = 0;

        public int time = 0;
        public int tControlNum = 0;
        public static ManualResetEvent threadEvent = new ManualResetEvent(false);
        public static System.Threading.AutoResetEvent WaitThread = new System.Threading.AutoResetEvent(false);
        List<String> dirList = new List<String>();
        List<Tools.ScanInfo> listViewList = new List<Tools.ScanInfo>();
        Tools.ScanInfo errorInfo = new Tools.ScanInfo();
        Task t;


        public CancellationTokenSource cts;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        #endregion


        #region 控件区
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        delegate void AddItemHandler(String url, String status, String length);
        private void AddItem(String url,String status, String length)
        {
            if (InvokeRequired)
            {
                Invoke(new AddItemHandler(AddItem), url,  status,  length);
                return;
            }
            ListViewItem item = new ListViewItem();
            item.Text = (listView_Result.Items.Count + 1).ToString();
            item.SubItems.Add(url);
            item.SubItems.Add(status);
            item.SubItems.Add(length);
            if (Convert.ToInt32(status) == 403)
            {
                item.ForeColor = Color.Red;
            }
            listView_Result.Items.Add(item);


        }

        delegate void ChangLabelHandler(String str);
        private void ChangUrlLabel(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new ChangLabelHandler(ChangUrlLabel), str);
                return;
            }
            label_Url.Text = "当前url：" + str;
        }

        private void ChangPercentageLabel(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new ChangLabelHandler(ChangPercentageLabel), str);
                return;
            }
            label_Percentage.Text = "完成情况："+ tCount + " / " + str;
        }

        private void ChangThreadNumLabel(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new ChangLabelHandler(ChangThreadNumLabel), str);
                return;
            }
            label_ThreadNum.Text = "当前线程：" + str;
        }

        private void ChangTimeNumLabel(String str)
        {
            if (InvokeRequired)
            {
                Invoke(new ChangLabelHandler(ChangTimeNumLabel), str);
                return;
            }
            label_Time.Text = "用时： " + str;
        }


        public void AddFilterItem(String code, String length)
        {
            ListViewItem item = new ListViewItem();
            item.Text = code;
            item.SubItems.Add(length);
            listView_Filter.Items.Add(item);
        }

        public void AddList(String str)
        {
            dirList.AddRange(Tools.FileTools.ReadFileToList(str));
            tCount = dirList.Count;
            ChangPercentageLabel("0");
        }

        public bool IsExistInListView(String statusCode,String length)
        {
            for (int i = 0; i < listView_Filter.Items.Count; i++)
            {
                //处理Item 
                ListViewItem item = listView_Filter.Items[i];


                //处理SubItem
                if (statusCode == item.SubItems[0].Text && length == item.SubItems[1].Text)
                {
                    return true;
                }

            }
            return false;
        }

        public void UpdateResultListView()
        {
            listView_Result.Items.Clear();
            foreach (var scanInfo in listViewList)
            {
                

                //处理SubItem
                if(!IsExistInListView(scanInfo.statusCode, scanInfo.length))
                {
                    AddItem(scanInfo.path,scanInfo.statusCode,scanInfo.length);
                }


            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        #endregion


        #region 函数区
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////

        public void MultiThreadScan()
        {
            cts = new CancellationTokenSource();
            tCount = dirList.Count;
            tNum = 0;
            

            Tools.WebHttp myWebHttp = new Tools.WebHttp();
            errorInfo = myWebHttp.GetHeaderTest(domain, "texc/testsdf4.php");

            foreach (String i in dirList)
            {
                Interlocked.Increment(ref tControlNum);
                if (tControlNum > 5 || tControlNum == 5)
                {
                    WaitThread.WaitOne();
                }
                ThreadPool.QueueUserWorkItem(new WaitCallback(SingleThreadScan), i);
                    
            }
            threadEvent.WaitOne();

            timer_info.Stop();
            timer_info.Enabled = false;

        }

        public void SingleThreadScan(object path)
        {
            if (!cts.IsCancellationRequested)
            {
                Tools.ScanInfo myScanInfo = new Tools.ScanInfo();
                Tools.WebHttp myWebHttp = new Tools.WebHttp();
                myScanInfo = myWebHttp.GetHeaderAsynT(domain, path.ToString());

                if (!((myScanInfo.statusCode == errorInfo.statusCode) && (myScanInfo.length == errorInfo.length)) && !((myScanInfo.statusCode == "404") && (myScanInfo.length == "0")))
                {
                    AddItem(domain + path.ToString(), myScanInfo.statusCode, myScanInfo.length);

                    myScanInfo.id = (listView_Result.Items.Count + 1).ToString();
                    myScanInfo.path = domain + path.ToString();
                    listViewList.Add(myScanInfo);
                }
                ChangUrlLabel(domain + path.ToString());
                ChangPercentageLabel(tNum.ToString());

                Interlocked.Decrement(ref tControlNum);
                if (tControlNum < 5)
                {
                    WaitThread.Set();
                }
            }

        }

        public void WafScan()
        {
            cts = new CancellationTokenSource();

            Tools.ScanInfo myScanInfo = new Tools.ScanInfo();
            Tools.WebHttp myWebHttp = new Tools.WebHttp();
            errorInfo = myWebHttp.GetHeaderTest(domain, "texc/testsdf4.php");
            Int32 okI = 0;
            foreach (var path in dirList)
            {
                if (!cts.IsCancellationRequested)
                {

                    myScanInfo = myWebHttp.GetHeaderWaf(domain, path, textBox_Mindelay.Text, textBox_MaxDelay.Text);
                    if (!((myScanInfo.statusCode == errorInfo.statusCode) && (myScanInfo.length == errorInfo.length)) && !((myScanInfo.statusCode == "404") && (myScanInfo.length == "0")))
                    {
                        AddItem(domain + path.ToString(), myScanInfo.statusCode, myScanInfo.length);
                        myScanInfo.id = (listView_Result.Items.Count + 1).ToString();
                        myScanInfo.path = domain + path.ToString();
                        listViewList.Add(myScanInfo);
                    }

                    ChangUrlLabel(domain + path.ToString());
                    ChangPercentageLabel((++okI).ToString());
                }

            }

            timer_info.Stop();
            timer_info.Enabled = false;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        #endregion


        #region 事件区
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void button_scan_Click(object sender, EventArgs e)
        {
            if (tCount == 0)
            {
                MessageBox.Show("请选择字典");
                return;
            }

            System.Net.ServicePointManager.DefaultConnectionLimit = 512;
            timer_info.Enabled = true;
            listView_Result.Items.Clear();
            domain = textBox_Domain.Text;
            time = 0;



            if (!radioButton_waf.Checked)
            {
                threadEvent = new ManualResetEvent(false);
                t = new Task(MultiThreadScan);
                t.Start();
            }
            else
            {
                Task t = new Task(WafScan);
                t.Start();
            }

        }


        #region 右键操作
        private void listView_re_DoubleClick(object sender, EventArgs e)
        {
            if (this.listView_Result.SelectedItems.Count == 0)
            {
                return;
            }
            string target = this.listView_Result.SelectedItems[0].SubItems[1].Text;

            try
            {

                System.Diagnostics.Process.Start(target);

            }
            catch (Exception)
            {
                MessageBox.Show("无法打开浏览器");
            }
        }

        private void ToolStripMenuItem_copy_Click(object sender, EventArgs e)
        {
            if (this.listView_Result.SelectedItems.Count == 0)
            {
                return;
            }
            Clipboard.SetText(this.listView_Result.SelectedItems[0].SubItems[1].Text);
        }

        private void ToolStripMenuItem_OpenAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView_Result.Items.Count; i++)
            {
                //处理Item 
                ListViewItem item = listView_Result.Items[i];
                System.Diagnostics.Process.Start(item.SubItems[1].Text);

            }
        }
        #endregion


        private void button_Filter_Click(object sender, EventArgs e)
        {
            FilterForm filterForm = new FilterForm();
            filterForm.ShowDialog(this);
        }

        private void listView_Result_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == 3)
            {
                listView_Result.ListViewItemSorter = new Tools.ListViewItemComparer(3);
                listView_Result.Sort();
            }
            else if (e.Column == 0)
            {
                listView_Result.ListViewItemSorter = new Tools.ListViewItemComparer(0);
                listView_Result.Sort();
            }
        }

        
        private void timer_info_Tick(object sender, EventArgs e)
        {
            
            int maxNum, num, portNum;
            ThreadPool.GetAvailableThreads(out num, out portNum);
            ThreadPool.GetMaxThreads(out maxNum, out portNum);
            ChangThreadNumLabel((maxNum - num).ToString());

            time = time + 1;
            ChangTimeNumLabel(time.ToString());
        }



        private void button_Restore_Click(object sender, EventArgs e)
        {
            listView_Filter.Items.Clear();
            listView_Result.Items.Clear();
            foreach (var item in listViewList)
            {
                AddItem(item.path, item.statusCode, item.length);

            }
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            cts.Cancel();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            DirectoryInfo folder = new DirectoryInfo(System.IO.Directory.GetCurrentDirectory());

            foreach (FileInfo file in folder.GetFiles("*.txt"))
            {
                StreamReader sr = new StreamReader(file.Name, System.Text.Encoding.Default);
                int i = 0;
                string s;
                while (sr.Peek() != -1)
                {
                    s = sr.ReadLine();
                    if (s != null && s != "")
                        i++;
                }
                
                ListViewItem item = new ListViewItem();
                item.Text = file.Name;
                item.SubItems.Add(i.ToString());
                listView_Checked.Items.Add(item);

            }
        }

        private void listView_Checked_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            List<String> checkedList = new List<String>();
            checkedList = Tools.FileTools.ReadFileToList(listView_Checked.Items[e.Index].SubItems[0].Text);
            if (!listView_Checked.Items[e.Index].Checked)//如果点击的CheckBoxes没有选中  
            {
                
                dirList.AddRange(checkedList);
                tCount = dirList.Count;
                ChangPercentageLabel("0");
            }
            else
            {
                //MessageBox.Show("no"+e.Index.ToString());
                dirList.RemoveAll(i=> 
                {
                    if (checkedList.Contains(i))
                        return true;
                    else
                        return false;
                 });
                tCount = dirList.Count;
                ChangPercentageLabel("0");
            }
        }

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    #endregion

}
